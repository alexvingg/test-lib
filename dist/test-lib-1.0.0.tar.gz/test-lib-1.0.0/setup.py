from setuptools import setup

setup(
    name='test-lib',
    version='1.0.0',
    description='test lib project',
    packages=['multiply',]
)