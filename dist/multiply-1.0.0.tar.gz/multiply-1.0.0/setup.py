from setuptools import setup

setup(
    name='multiply',
    version='1.0.0',
    description='test lib multiply project',
    packages=['multiply',]
)